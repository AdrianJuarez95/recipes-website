import { RecipeFilterPipe } from './recipe-filter.pipe';

describe('RecipeFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new RecipeFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
