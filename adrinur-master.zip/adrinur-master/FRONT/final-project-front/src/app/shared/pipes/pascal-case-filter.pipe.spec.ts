import { PascalCaseFilterPipe } from './pascal-case-filter.pipe';

describe('PascalCaseFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new PascalCaseFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
