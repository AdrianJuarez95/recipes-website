export interface Responses {
  expires: number;
  accessToken: string;
}
