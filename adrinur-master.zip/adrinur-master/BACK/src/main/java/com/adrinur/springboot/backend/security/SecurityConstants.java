package com.adrinur.springboot.backend.security;

public class SecurityConstants {

	public static final String SECRET_KEY = "adrinurFinalProjectEOI2020";
}
